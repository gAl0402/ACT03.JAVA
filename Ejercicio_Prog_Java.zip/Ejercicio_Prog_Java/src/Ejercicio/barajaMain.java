package Ejercicio;

import java.util.*;

import baraja.BarajaFrancesa;
import baraja.Carta;

public class barajaMain {

    public static void main(String[] args) {

        //Creamos la baraja
        BarajaFrancesa b = new BarajaFrancesa();
        
        int n;
        Scanner leer = new Scanner(System.in);
        
        do {
        System.out.println();
        System.out.println("1. Crear Baraja");
        System.out.println("2. Mostrar Baraja");
        System.out.println("3. Pedir Carta");
        System.out.println("4. Dar Mano de Cartas");
        System.out.println("5. Salir");
        
        System.out.println("Elige una opci�n del menu: ");
        
        n = leer.nextInt();
        
	        switch(n) {
	        
	        case 1:
	        		b.crearBaraja();
	        		b.barajar();
	        		System.out.println("Se ha creado la baraja");
	        		break;
	        case 2:
	    			b.mostrarBaraja();
	    			break;
	        case 3:
	    			b.darCartas(1);
	    			 //Mostramos las cartas disponibles
	    	        System.out.println("Hay " + b.cartasDisponible() + " cartas disponibles");
	    			break;
	        case 4:
				b.darCartas(5);
				 //Mostramos las cartas disponibles
		        System.out.println("Hay " + b.cartasDisponible() + " cartas disponibles");
				break;
	        }
        }while(n < 5);
       
    }

}
